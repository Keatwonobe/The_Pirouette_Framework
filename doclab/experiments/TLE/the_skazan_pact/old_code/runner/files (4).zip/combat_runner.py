#!/usr/bin/env python3
"""
combat_runner.py - Main orchestrator for TLE combat system

Modular combat runner integrating:
- Character state management
- Check system (skill-based information revelation)
- Dice buy system (entropy gambling)
- Spellcasting (range-based EP costs)
- Social/conversation mechanics
- AI behavior
- Damage and wound channels
- Influence system
- Player interface
"""

import os
from character_state import (
    load_initiative, load_new_characters, save_back_vessels,
    init_social_flags, rebuild_initiative, print_state
)
from utils import load_dir_as_map
from player_interface import handle_player_turn, preflight_setup
from ai_system import ai_take_turn
from influence_system import start_of_round_reactions


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
AXES_DIR = os.path.join(BASE_DIR, "axes")
INFL_DIR = os.path.join(BASE_DIR, "influences")
ITEMS_DIR = os.path.join(BASE_DIR, "items")
SPELLS_DIR = os.path.join(BASE_DIR, "spells")


def main():
    """Main combat runner loop"""
    print("="*60)
    print("  TLE Combat Runner - Modular Edition")
    print("="*60)
    
    # Load libraries
    print("\nLoading libraries...")
    axes_lib = load_dir_as_map(AXES_DIR)
    infl_lib = load_dir_as_map(INFL_DIR)
    items_lib = load_dir_as_map(ITEMS_DIR)
    spells_lib = load_dir_as_map(SPELLS_DIR)
    
    libs = {
        "axes": axes_lib,
        "influences": infl_lib,
        "items": items_lib,
        "spells": spells_lib
    }
    
    print(f"  Axes: {len(axes_lib)}")
    print(f"  Influences: {len(infl_lib)}")
    print(f"  Items: {len(items_lib)}")
    print(f"  Spells: {len(spells_lib)}")
    
    # Load characters
    chars = load_initiative()
    if not chars:
        print("\nNo characters found in ./initiative directory")
        print("Please add character JSON files to ./initiative/ and try again.")
        return
    
    print(f"\nLoaded {len(chars)} characters")
    
    # Initialize sides and player detection
    for ch in chars:
        if ch.get("player", False) or str(ch.get("id", "")).startswith("player-"):
            ch["side"] = "players"
            ch["player"] = True
        else:
            ch.setdefault("side", "raiders")
    
    # Initialize social flags
    init_social_flags(chars)
    
    # Pre-flight setup
    print("\nEntering pre-flight setup...")
    if not preflight_setup(chars):
        print("Combat cancelled.")
        return
    
    # Track if this was a player scene
    had_players = any(c.get("side") == "players" for c in chars)
    
    # Main combat loop
    max_rounds = 20
    for rnd in range(1, max_rounds + 1):
        print("\n" + "="*60)
        print(f"  ROUND {rnd}")
        print("="*60)
        
        # Check for new combatants
        new_chars = load_new_characters(chars)
        if new_chars:
            print(f"\n[JOIN] {len(new_chars)} new combatant(s) enter the fray!")
            for nc in new_chars:
                print(f"  + {nc['name']} [{nc.get('side', '?')}]")
            chars.extend(new_chars)
        
        # Rebuild initiative
        order = rebuild_initiative(chars)
        
        # Start of round reactions
        start_of_round_reactions(chars, libs)
        
        # Check victory condition
        alive_sides = {c["side"] for c in chars if c["pools"]["HP"] > 0}
        
        if len(alive_sides) <= 1 and had_players:
            print("\n" + "="*60)
            if "players" in alive_sides:
                print("  VICTORY! Players win!")
            else:
                print("  DEFEAT! All players have fallen!")
            print("="*60)
            break
        
        if len(alive_sides) == 0:
            print("\n" + "="*60)
            print("  DRAW! All combatants defeated!")
            print("="*60)
            break
        
        # Process turns
        for ch in order:
            if ch["pools"]["HP"] <= 0:
                continue
            
            if ch.get("player", False):
                handle_player_turn(ch, chars, libs)
            else:
                if not ch.get("ai_enabled", True):
                    print(f"\n{ch['name']} (AI disabled) takes no action.")
                else:
                    ai_take_turn(ch, chars, libs)
        
        # Remove defeated characters
        chars = [c for c in chars if c["pools"]["HP"] > 0]
        
        if not chars:
            print("\nAll characters defeated!")
            break
    
    # Save character states
    print("\n" + "="*60)
    print("  Combat Complete - Saving Character States")
    print("="*60)
    
    save_back_vessels(chars)
    print("Character states saved to ./initiative/")
    print("\nSession complete!")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nCombat interrupted by user.")
    except Exception as e:
        print(f"\n\nError during combat: {e}")
        import traceback
        traceback.print_exc()
