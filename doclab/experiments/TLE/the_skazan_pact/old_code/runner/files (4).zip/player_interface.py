#!/usr/bin/env python3
"""
player_interface.py - Handle player turns and CLI commands
"""

from utils import parse_index_tokens
from character_state import print_state
from social_system import conversation_check, set_stance, set_hostility
from check_system import handle_check_command
from dice_buy import handle_dice_buy_attack, parse_dice_buy_command, explain_dice_buy_options
from spellcasting import resolve_spell_cast, handle_split_cast, explain_spellcasting
from damage_system import route_damage_to_wounds
from influence_system import resolve_item_use


def handle_player_turn(character, all_chars, libs):
    """
    Handle a player character's turn with CLI interface.
    
    Args:
        character: Player character
        all_chars: All characters in combat
        libs: Library dict
    """
    print(f"\n{'='*60}")
    print(f"  {character['name']}'s TURN")
    print(f"  HP: {character['pools']['HP']}/{character['pools']['max_HP']} | "
          f"EP: {character['pools']['EP']}/{character['pools']['max_EP']}")
    print(f"{'='*60}")
    
    # Show nearby enemies
    print("\nTargets:")
    for i, ch in enumerate(all_chars, 1):
        if ch["pools"]["HP"] <= 0:
            continue
        if ch is character:
            continue
        
        hp = ch["pools"]["HP"]
        max_hp = ch["pools"]["max_HP"]
        side = ch.get("side", "?")
        hostility = ch.get("hostility", "neutral")
        
        print(f"  [{i}] {ch['name']:<20} | {side:<10} | HP {hp}/{max_hp} | {hostility}")
    
    print("\nCommands:")
    print("  attack <target> spend <ep> [buy <ep>]   - Attack with optional dice buy")
    print("  cast <spell> <target> spend <ep> range <ep> - Cast spell")
    print("  check <target>.<field> [auto/manual]    - Skill check")
    print("  check list <target>                     - List checkable fields")
    print("  use <item> [on <target>]                - Use item")
    print("  talk <target> [stat]                    - Conversation check")
    print("  move <x> <y>                            - Move to position")
    print("  look                                    - View battlefield")
    print("  pass / skip                             - End turn")
    print("  help dice                               - Explain dice buy system")
    print("  help spells                             - Explain spellcasting")
    print()
    
    while True:
        try:
            cmd = input(f"{character['name']}> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nSkipping turn.")
            return
        
        if not cmd:
            continue
        
        parts = cmd.split()
        op = parts[0].lower()
        
        # === HELP COMMANDS ===
        if op == "help":
            if len(parts) > 1:
                topic = parts[1].lower()
                if topic in ("dice", "buy"):
                    explain_dice_buy_options()
                elif topic in ("spell", "spells", "cast"):
                    explain_spellcasting()
                else:
                    print("Help topics: dice, spells")
            else:
                print("Available help: dice, spells")
            continue
        
        # === END TURN ===
        if op in ("pass", "skip", "done", "end"):
            print(f"{character['name']} ends turn.")
            return
        
        # === LOOK ===
        if op == "look":
            print_state(all_chars)
            continue
        
        # === ATTACK ===
        if op == "attack":
            parsed = parse_dice_buy_command(parts)
            if not parsed:
                print("Usage: attack <target> spend <base_ep> [buy <buy_ep>]")
                continue
            
            target_idx, base_ep, buy_ep = parsed
            
            if target_idx < 0 or target_idx >= len(all_chars):
                print("Invalid target index")
                continue
            
            target = all_chars[target_idx]
            
            if target["pools"]["HP"] <= 0:
                print("Target is already defeated")
                continue
            
            # Check EP
            total_ep = base_ep + buy_ep
            if character["pools"]["EP"] < total_ep:
                print(f"Insufficient EP! Need {total_ep}, have {character['pools']['EP']}")
                continue
            
            # Execute attack
            handle_dice_buy_attack(character, target, base_ep, buy_ep, libs)
            character["pools"]["EP"] -= total_ep
            return
        
        # === CHECK ===
        if op == "check":
            handle_check_command(parts, character, all_chars)
            continue
        
        # === CAST ===
        if op == "cast":
            if len(parts) < 6:
                print("Usage: cast <spell> <target> spend <ep> range <ep>")
                continue
            
            spell_id = parts[1]
            
            try:
                target_idx = int(parts[2]) - 1
            except ValueError:
                print("Invalid target index")
                continue
            
            if target_idx < 0 or target_idx >= len(all_chars):
                print("Invalid target index")
                continue
            
            target = all_chars[target_idx]
            
            # Parse EP amounts
            if "spend" not in parts or "range" not in parts:
                print("Usage: cast <spell> <target> spend <ep> range <ep>")
                continue
            
            spend_idx = parts.index("spend")
            range_idx = parts.index("range")
            
            try:
                damage_ep = int(parts[spend_idx + 1])
                range_ep = int(parts[range_idx + 1])
            except (ValueError, IndexError):
                print("Invalid EP values")
                continue
            
            total_ep = damage_ep + range_ep
            if character["pools"]["EP"] < total_ep:
                print(f"Insufficient EP! Need {total_ep}, have {character['pools']['EP']}")
                continue
            
            # Cast spell
            result = resolve_spell_cast(
                character, target, spell_id,
                damage_ep, range_ep, libs, mode="auto"
            )
            
            if result.get("success"):
                log = []
                route_damage_to_wounds(target, result["damage"], "arcane", log)
                for line in log:
                    print(f"  {line}")
                character["pools"]["EP"] -= total_ep
                return
            else:
                # Spell failed, still costs EP
                character["pools"]["EP"] -= total_ep
                return
        
        # === USE ITEM ===
        if op == "use":
            if len(parts) < 2:
                print("Usage: use <item> [on <target>]")
                continue
            
            item_id = parts[1]
            
            # Determine target
            target = character  # Default to self
            if "on" in parts:
                on_idx = parts.index("on")
                if on_idx + 1 < len(parts):
                    try:
                        target_idx = int(parts[on_idx + 1]) - 1
                        if 0 <= target_idx < len(all_chars):
                            target = all_chars[target_idx]
                    except ValueError:
                        pass
            
            result = resolve_item_use(character, item_id, target, libs)
            
            if result["success"]:
                for line in result["log"]:
                    print(f"  {line}")
                return
            else:
                print(f"Cannot use item: {result['reason']}")
                continue
        
        # === TALK ===
        if op == "talk":
            if len(parts) < 2:
                print("Usage: talk <target> [stat]")
                continue
            
            try:
                target_idx = int(parts[1]) - 1
            except ValueError:
                print("Invalid target index")
                continue
            
            if target_idx < 0 or target_idx >= len(all_chars):
                print("Invalid target index")
                continue
            
            target = all_chars[target_idx]
            stat = parts[2] if len(parts) > 2 else "wis"
            
            conversation_check(character, target, stat=stat, mode="auto")
            return
        
        # === MOVE ===
        if op == "move":
            if len(parts) < 3:
                print("Usage: move <x> <y>")
                continue
            
            try:
                x = float(parts[1])
                y = float(parts[2])
            except ValueError:
                print("Invalid coordinates")
                continue
            
            character["position"] = {"x": x, "y": y}
            print(f"{character['name']} moves to ({x}, {y})")
            return
        
        print("Unknown command. Type 'help' for available commands.")


def preflight_setup(chars):
    """
    Pre-combat setup phase for GM to configure battlefield.
    
    Args:
        chars: All characters
    
    Returns:
        True to start combat, False to exit
    """
    while True:
        print("\n" + "="*60)
        print("  PRE-FLIGHT SETUP")
        print("="*60)
        print("\nCommands:")
        print("  start / go              - Begin combat")
        print("  quit / exit             - Exit without combat")
        print("  ai on|off <idx>         - Toggle AI")
        print("  mode <idx> <type>       - Set stance (combat/talk/neutral)")
        print("  hostility <idx> <state> - Set hostility (hostile/neutral/friendly)")
        print("  side <idx> <label>      - Change team/side")
        print("  look                    - View battlefield")
        print()
        
        print_state(chars)
        
        cmd = input("setup> ").strip()
        if not cmd:
            continue
        
        parts = cmd.split()
        op = parts[0].lower()
        
        # === START/QUIT ===
        if op in ("start", "go", "run", "begin"):
            return True
        
        if op in ("q", "quit", "exit"):
            print("Exiting without running combat.")
            return False
        
        # === LOOK ===
        if op == "look":
            continue
        
        # === AI TOGGLE ===
        if op == "ai":
            if len(parts) < 3:
                print("Usage: ai on|off <idx>")
                continue
            
            mode = parts[1].lower()
            if mode not in ("on", "off"):
                print("Mode must be 'on' or 'off'")
                continue
            
            indices = parse_index_tokens(parts[2:], len(chars))
            if not indices:
                print("No valid indices")
                continue
            
            val = (mode == "on")
            for i in indices:
                ch = chars[i]
                ch["ai_enabled"] = val
                print(f"AI {'ON' if val else 'OFF'} for [{i+1}] {ch['name']}")
            continue
        
        # === MODE ===
        if op == "mode":
            if len(parts) < 3:
                print("Usage: mode <idx> <type> (combat/talk/neutral)")
                continue
            
            mode_str = parts[-1].lower()
            if mode_str in ("talk", "conv", "conversation"):
                new_mode = "conversation"
            elif mode_str in ("combat", "fight"):
                new_mode = "combat"
            elif mode_str in ("neutral", "idle"):
                new_mode = "neutral"
            else:
                print("Unknown mode. Use: combat, talk, neutral")
                continue
            
            indices = parse_index_tokens(parts[1:-1], len(chars))
            if not indices:
                print("No valid indices")
                continue
            
            for i in indices:
                set_stance(chars[i], new_mode)
            continue
        
        # === HOSTILITY ===
        if op == "hostility":
            if len(parts) < 3:
                print("Usage: hostility <idx> <state> (hostile/neutral/friendly)")
                continue
            
            state = parts[-1].lower()
            if state not in ("hostile", "neutral", "friendly"):
                print("Unknown hostility. Use: hostile, neutral, friendly")
                continue
            
            indices = parse_index_tokens(parts[1:-1], len(chars))
            if not indices:
                print("No valid indices")
                continue
            
            for i in indices:
                set_hostility(chars[i], state)
            continue
        
        # === SIDE ===
        if op == "side":
            if len(parts) < 3:
                print("Usage: side <idx> <label>")
                continue
            
            new_side = parts[-1]
            indices = parse_index_tokens(parts[1:-1], len(chars))
            if not indices:
                print("No valid indices")
                continue
            
            for i in indices:
                ch = chars[i]
                old_side = ch.get("side", "?")
                ch["side"] = new_side
                print(f"[{i+1}] {ch['name']}: {old_side} → {new_side}")
            continue
        
        print("Unknown command")
