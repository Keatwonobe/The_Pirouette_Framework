#!/usr/bin/env python3
import json, random, hashlib, datetime
from pathlib import Path

BASE = Path(__file__).parent
ROSTER = BASE/"roster"
SCENES = BASE/"scenes"
LOGS = BASE/"logs"
WORLD = json.loads((BASE/"world.json").read_text())

def load_json(fp): return json.loads(Path(fp).read_text())
def mk_id(prefix, i): return f"{prefix}-{i:03d}"

def mk_from_template(tpl, idx):
    return {
      "id": mk_id(tpl.get("template","unit"), idx),
      "name": tpl.get("template","Unit").replace("_"," ").title() + f" {idx}",
      "side": tpl.get("side","neutral"),
      "faction": tpl.get("faction","wilds"),
      "persona": {"archetype": tpl.get("archetype","pragmatic"),
                  "courage": tpl.get("courage",0.5),
                  "temper": tpl.get("temper",0.5),
                  "tactics": tpl.get("tactics",["focus_fire","use_cover"]) },
      "stats": { "TEP": tpl["stats"]["TEP"], "ERR": tpl["stats"]["ERR"], "STR": tpl["stats"]["STR"],
                 "DEX": tpl["stats"]["DEX"], "CON": tpl["stats"]["CON"], "INT": tpl["stats"]["INT"],
                 "WIS": tpl["stats"]["WIS"], "init_bonus": tpl["stats"]["init_bonus"] },
      "pools": {"HP": tpl["pools"]["HP"], "AEP": tpl["pools"]["AEP"], "arcana":[], "skills":[]},
      "form": {"limbs":[{"type":"arm","ep":3},{"type":"arm","ep":3},{"type":"leg","ep":3},{"type":"leg","ep":3}],"wings": False},
      "constitution": {"resolve": tpl["stats"]["INT"]+5, "composure": tpl["stats"]["WIS"]+5, "tenets": []},
      "position":{"x":0,"y":0}, "meta":{"notes":""}, "history":[]
    }

def collect_participants(scene):
    chars = []
    for part in scene["participants"]:
        if "id" in part:
            fp = ROSTER/f"{part['id']}.json"
            if fp.exists():
                j = load_json(fp); j.setdefault("history",[]); chars.append(j)
        elif "template" in part:
            for i in range(1, part.get("count",1)+1): chars.append(mk_from_template(part, i))
    return chars

TAUNTS = ["You sure about this?","Turn back now.","You'll regret this.","Lay down arms and live.","Speak your last."]

def affinity(a, b):
    same = 0.2 if a.get("side")==b.get("side") else 0.0
    ta = set(a.get("constitution",{}).get("tenets",[])); tb = set(b.get("constitution",{}).get("tenets",[]))
    return same + 0.1*len(ta.intersection(tb))

def pre_entropy_phase(chars):
    roles, barks = {}, []
    for ch in chars:
        courage = ch["persona"].get("courage",0.5); arch = ch["persona"]["archetype"]
        same_aff=opp_aff=0.0; same_n=opp_n=0
        for o in chars:
            if o["id"]==ch["id"]: continue
            a = affinity(ch,o)
            if o.get("side")==ch.get("side"): same_aff+=a; same_n+=1
            else: opp_aff+=a; opp_n+=1
        pressure = courage + 0.2*((same_aff/max(1,same_n)) - (opp_aff/max(1,opp_n)))
        if arch=="cowardly" and pressure<0.55: roles[ch["id"]] = "withdraw"
        elif arch=="parleyist" and random.random()<0.6: roles[ch["id"]] = "taunt"
        else:
            roles[ch["id"]] = "watch" if (random.random()<0.3 and pressure<0.7) else "ready"
        if roles[ch["id"]]=="taunt": barks.append(f"- {ch['name']}: \"{random.choice(TAUNTS)}\"")
    watchers=[c for c in chars if roles[c["id"]]=="watch"]
    fighters=[c for c in chars if roles[c["id"]] in ("ready","taunt")]
    withdrawn=[c for c in chars if roles[c["id"]]=="withdraw"]
    side_counts={}
    for f in fighters: side_counts[f.get("side","neutral")] = side_counts.get(f.get("side","neutral"),0)+1
    support={}
    for w in watchers:
        if not side_counts: continue
        underdog = min(side_counts, key=side_counts.get)
        choice = underdog if random.random()<0.5 else w.get("side","neutral")
        support[choice] = support.get(choice,0)+1; w["_opinion"] = f"cheer:{choice}"
    morale = {side: support.get(side,0)//5 for side in side_counts.keys()}
    prelude = []
    rc = {"withdraw":len(withdrawn),"watch":len(watchers),"taunt":sum(1 for c in chars if roles[c['id']]=='taunt'),"ready":sum(1 for c in chars if roles[c['id']]=='ready')}
    prelude.append("### Prelude (Pre-Entropy Phase)")
    prelude.append(f"- Withdraw: {rc['withdraw']}  |  Watch: {rc['watch']}  |  Taunt: {rc['taunt']}  |  Ready: {rc['ready']}")
    if barks: prelude.append("\n**Barks**"); prelude.extend(barks)
    if any(v>0 for v in morale.values()):
        s = ", ".join([f"{k}: +{v} ERR" for k,v in morale.items() if v>0]); prelude.append(f"\n**Morale (spectators → fighters):** {s}")
    return fighters, watchers, withdrawn, prelude, morale, roles

def choose_target(me, enemies):
    if not enemies: return None
    enemies.sort(key=lambda e: (e["pools"]["HP"], e["pools"]["AEP"]))
    return enemies[0]

def take_turn(ch, enemies, trace):
    if ch["pools"]["HP"]<=0: return 0, 0
    err = ch["_err"]; bursty = ch["persona"].get("temper",0.5) > 0.6
    spend = err if bursty else max(1, err//2)
    tn = WORLD["rules"]["tn_base"] + (spend//2)
    atk = random.randint(1,20) + (ch["stats"]["DEX"]//4) + (ch["stats"]["INT"]//4)
    ch["_err"] -= spend
    if atk < tn or not enemies:
        trace.append(f"- {ch['name']} tests the line (miss at EP {spend}, TN {tn}, roll {atk})."); return spend, 0
    tgt = choose_target(ch, enemies)
    defend = min(spend, max(0, tgt["_err"]//2)); tgt["_err"] -= defend
    dmg = max(0, spend - defend); soak = min(dmg, tgt["pools"]["AEP"]); tgt["pools"]["AEP"] -= soak; dmg -= soak
    tgt["pools"]["HP"] -= dmg; 
    if tgt["pools"]["HP"]<=0: tgt["_alive"]=False
    trace.append(f"- {ch['name']} strikes {tgt['name']} for {dmg} (def {defend}, soak {soak}). {tgt['pools']['HP']} HP.")
    tgt["_taken"] = tgt.get("_taken",0) + dmg
    return spend, dmg

def run_crowd(scene_path="encounter_example.json", max_rounds=30):
    scene = json.loads((SCENES/scene_path).read_text())
    chars = collect_participants(scene)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    ek = hashlib.sha1((WORLD["name"] + '|' + ','.join(sorted([c['id'] for c in chars])) + '|' + ts).encode()).hexdigest()[:12]
    for c in chars: c.update({"_alive": c["pools"]["HP"]>0, "_err": c["stats"]["ERR"], "_dealt":0, "_taken":0})
    log = [f"# Crowd Encounter {scene['title']}  ({ek})", f"World: {WORLD['name']}", f"Participants: {len(chars)}"]
    fighters, watchers, withdrawn, prelude, morale, roles = pre_entropy_phase(chars)
    log.extend(prelude)
    groups = {}
    for f in fighters: groups.setdefault(f.get("side","neutral"), []).append(f)
    helix = []; rnd = 1
    while rnd<=max_rounds and len([g for g in groups.values() if any(c['_alive'] for c in g)])>1:
        for side, members in groups.items():
            bonus = morale.get(side,0)
            for c in members:
                if c["_alive"]: c["_err"] = c["stats"]["ERR"] + bonus
        log.append(f"\n## Round {rnd}")
        for side, members in groups.items():
            enemies = [e for s2,gg in groups.items() if s2!=side for e in gg if e["_alive"]]
            for ch in [m for m in members if m["_alive"]]:
                spend, dealt = take_turn(ch, enemies, log); ch["_dealt"] += dealt
        helix.append({k: sum(1 for m in v if m["_alive"]) for k,v in groups.items()})
        rnd += 1
    survivors = {k:[m for m in v if m["_alive"]] for k,v in groups.items()}
    winners = [k for k,v in survivors.items() if len(v)>0]
    outcome = f"Victors: {', '.join(winners)}" if len(winners)==1 else ("Stalemate" if len(winners)>1 else "Mutual ruin")
    log.append(f"\n**Outcome:** {outcome}")
    keys = list(groups.keys()); log.append("\n### Numbers Trace (alive per round)")
    header = "| Round | " + " | ".join(keys) + " |"; sep = "|---:" + "|".join(["---:"]*len(keys)) + "|"
    log.append(header); log.append(sep)
    for i,c in enumerate(helix, start=1): log.append("| "+str(i)+" | " + " | ".join(str(c.get(k,0)) for k in keys) + " |")
    out = LOGS/f"crowd_{ek}.md"; out.write_text("\n".join(log))
    print(f"Wrote crowd log: {out}")
    # Persist roster histories
    for ch in chars:
        src_fp = ROSTER/f"{ch['id']}.json"
        if src_fp.exists():
            src = json.loads(src_fp.read_text()); hist = src.get("history", [])
            result = "survived" if ch.get("_alive",True) else "fell"
            entry = {"encounter_key": ek, "ts": ts, "role": "crowd",
                     "pre_role": roles.get(ch["id"],"n/a"), "opinion": ch.get("_opinion",""),
                     "faction": ch.get("side",""), "rounds": rnd-1,
                     "dealt": int(ch.get("_dealt",0)), "taken": int(ch.get("_taken",0)),
                     "result": result}
            hist.append(entry); src["history"] = hist[-50:]; src_fp.write_text(json.dumps(src, indent=2))

if __name__ == "__main__":
    run_crowd()
