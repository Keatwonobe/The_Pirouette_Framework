#!/usr/bin/env python3
import json, random, datetime
from pathlib import Path
BASE = Path(__file__).parent
ROSTER = BASE/"roster"
INIT = BASE/"initiative"
LOGS = BASE/"logs"
WORLD = json.loads((BASE/"world.json").read_text())

def load_char(fp):
    j = json.loads(Path(fp).read_text())
    j["_alive"] = j["pools"]["HP"]>0
    j["_err"] = j["stats"]["ERR"]
    j["_spoken"] = False
    return j

def roll_initiative(j): return random.randint(1,20) + j["stats"]["init_bonus"] + (j["stats"]["DEX"]//4)
def accuracy_tn(ep): return WORLD["rules"]["tn_base"] + (ep//2)
def roll_d20(): return random.randint(1,20)

def choose_action(j, others):
    arch = j["persona"]["archetype"]; err = j["_err"]; hp=j["pools"]["HP"]
    low = hp <= 0.3*(j["stats"]["CON"]+14)
    if arch=="parleyist" and not j["_spoken"]:
        j["_spoken"]=True; return ("talk","Lay down arms and live.",None)
    if arch=="cowardly" and low: return ("reposition", max(1, err//2), None)
    return ("attack", max(1, min(3, err)), pick_target(j, others))

def pick_target(j, others):
    enemies=[o for o in others if o["side"]!=j["side"] and o["_alive"]]
    enemies.sort(key=lambda o:o["pools"]["HP"])
    return enemies[0]["id"] if enemies else None

def resolve_attack(attacker, target, ep):
    tn = accuracy_tn(ep)
    atk = roll_d20() + (attacker["stats"]["DEX"]//4) + (attacker["stats"]["INT"]//4)
    line = f"{attacker['name']} spends {ep} EP to attack (TN {tn}) → roll total {atk}."
    if atk < tn: return line + " Miss."
    defend = min(ep, target["_err"]//2); target["_err"] -= defend
    dmg = max(0, ep - defend); soak = min(dmg, target["pools"]["AEP"])
    target["pools"]["AEP"] -= soak; dmg -= soak
    target["pools"]["HP"] -= dmg
    if target["pools"]["HP"]<=0: target["_alive"]=False
    return line + f" Hit! Def {defend}, Soak {soak}, HP -{dmg} → {target['pools']['HP']}." + ("" if target["_alive"] else f" {target['name']} falls.")

def resolve_defend(j, ep): j["_err"] -= ep; return f"{j['name']} sets {ep} EP for Active Defense."
def resolve_reposition(j, ep): j["_err"] -= ep; return f"{j['name']} repositions {ep} squares."
def resolve_talk(j, text): return f"{j['name']} calls out: \"{text}\""

def run_round(chars, rnd, log):
    for ch in chars:
        if ch["_alive"]:
            ch["_err"] = ch["stats"]["ERR"]
            ch["_spoken"] = False
    order = sorted([ch for ch in chars if ch["_alive"]], key=lambda c: -roll_initiative(c))
    log.append(f"\\n## Round {rnd}")
    for ch in order:
        if not ch["_alive"]: continue
        others = [o for o in chars if o["id"]!=ch["id"]]
        verb = choose_action(ch, others)
        if verb[0]=="attack" and ch["_err"]>0:
            ep = min(verb[1], ch["_err"]); ch["_err"] -= ep
            tgt = [o for o in others if o["id"]==verb[2]]
            out = resolve_attack(ch, tgt[0], ep) if tgt else f"{ch['name']} hesitates."
        elif verb[0]=="defend":
            ep = min(verb[1], ch["_err"]); out = resolve_defend(ch, ep)
        elif verb[0]=="reposition":
            ep = min(verb[1], ch["_err"]); out = resolve_reposition(ch, ep)
        elif verb[0]=="talk": out = resolve_talk(ch, verb[1])
        else: out = f"{ch['name']} waits."
        log.append(f"- {out}")
    alive_sides = set([ch["side"] for ch in chars if ch["_alive"]])
    return len(alive_sides) <= 1

def main():
    chars = [load_char(fp) for fp in INIT.glob("*.json")]
    if not chars: print("No characters in initiative/."); return
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    md = [f"# Combat Log {stamp}", f"World: {WORLD['name']}"]
    rnd = 1
    while rnd<50:
        if run_round(chars, rnd, md): break
        rnd+=1
    sides = [ch["side"] for ch in chars if ch["_alive"]]
    md.append(f"\\n**Outcome:** {sides[0]} stand(s) victorious." if sides else "\\n**Outcome:** Mutual ruin.")
    outpath = LOGS/f"combat_{stamp}.md"; outpath.write_text("\\n".join(md))
    print(f"Wrote log: {outpath}")
    for ch in chars:
        (INIT/f"{ch['id']}.json").write_text(json.dumps(ch, indent=2))

if __name__ == "__main__": main()
