
TLE World Manager — JSON-first
==============================
- world_manager.py : turn-runner (initiative folder)
- crowd_runner.py  : Pre-Entropy Phase + crowd simulation (parley → factionalize → fight)
- world.json       : rules
- schemas/*.json   : character & world schemas
- roster/*.json    : example characters
- scenes/encounter_example.json : crowd demo
- logs/            : output narration + numbers trace
