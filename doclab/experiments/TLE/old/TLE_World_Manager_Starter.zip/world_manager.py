#!/usr/bin/env python3
import json, os, random, time, sys, math, shutil, datetime
from pathlib import Path

BASE = Path(__file__).parent
ROSTER = BASE/"roster"
INIT = BASE/"initiative"
LOGS = BASE/"logs"

WORLD = json.loads((BASE/"world.json").read_text())

def load_char(fp):
    j = json.loads(Path(fp).read_text())
    j["_fp"] = str(fp)
    j["_alive"] = True if j["pools"]["HP"]>0 else False
    j["_err"] = j["stats"]["ERR"]
    j["_spoken"] = False
    return j

def copy_into_initiative(ids=None):
    INIT.mkdir(exist_ok=True, parents=True)
    for fp in ROSTER.glob("*.json"):
        j = json.loads(fp.read_text())
        if (ids is None) or (j["id"] in ids):
            shutil.copy(fp, INIT/fp.name)

def roll_initiative(j):
    return random.randint(1,20) + j["stats"]["init_bonus"] + (j["stats"]["DEX"]//4)

def accuracy_tn(ep):
    return WORLD["rules"]["tn_base"] + (ep//2)

def choose_action(j, others):
    courage = j["persona"]["courage"]
    temper = j["persona"]["temper"]
    hp = j["pools"]["HP"]
    aep = j["pools"]["AEP"]
    err = j["_err"]
    low_hp = hp <= 0.3* (j["stats"]["CON"] + 14)
    arch = j["persona"]["archetype"]
    if arch == "cowardly":
        if low_hp or courage < 0.4:
            if not j["_spoken"] and random.random()<0.7:
                j["_spoken"]=True
                return ("talk","We don't need to do this!", None)
            return ("reposition", max(1, err//2), None)
        return ("attack", max(1, min(3, err-1)), pick_target(j, others))
    if arch == "parleyist":
        if not j["_spoken"]:
            j["_spoken"]=True
            return ("talk","Lay down arms and we all live.", None)
        if random.random()<0.5:
            return ("defend", max(1, err//2), None)
        return ("attack", max(1, min(2, err-1)), pick_target(j, others, prefer="lowest_hp"))
    if arch == "intrepid":
        spend = max(2, err)
        return ("attack", spend, pick_target(j, others, prefer="nearest"))
    if arch == "guardian":
        if random.random()<0.5:
            return ("defend", max(1, err//2), None)
        return ("attack", max(1, min(3, err)), pick_target(j, others, prefer="threat"))
    if arch == "assassin":
        return ("attack", max(2, err), pick_target(j, others, prefer="lowest_hp"))
    return ("attack", max(1, min(2, err)), pick_target(j, others))

def pick_target(j, others, prefer=None):
    enemies = [o for o in others if o["side"]!=j["side"] and o["_alive"]]
    if not enemies:
        return None
    if prefer=="lowest_hp":
        enemies.sort(key=lambda o:o["pools"]["HP"])
    elif prefer=="nearest":
        enemies.sort(key=lambda o: (abs(o["position"]["x"]-j["position"]["x"]) + abs(o["position"]["y"]-j["position"]["y"])))
    return enemies[0]["id"]

def roll_d20():
    return random.randint(1,20)

def resolve_attack(attacker, target, ep):
    tn = accuracy_tn(ep)
    attack_total = roll_d20() + (attacker["stats"]["DEX"]//4) + (attacker["stats"]["INT"]//4)
    line = f"{attacker['name']} spends {ep} EP to attack (TN {tn}) → roll total {attack_total}."
    prevented = 0
    if attack_total >= tn:
        defend_ep = min(ep, target["_err"]//2) if target["_err"]>0 else 0
        prevented = defend_ep
        target["_err"] -= defend_ep
        damage = max(0, ep - prevented)
        soak = min(damage, target["pools"]["AEP"])
        target["pools"]["AEP"] -= soak
        damage -= soak
        target["pools"]["HP"] -= damage
        if target["pools"]["HP"]<=0:
            target["_alive"]=False
        return line + (f" Hit! {target['name']} defends {prevented} EP; AEP soaks {soak}; HP -{damage} → {target['pools']['HP']} HP.") + ("" if target["_alive"] else f" {target['name']} falls.")
    else:
        return line + " Miss."

def resolve_defend(j, ep):
    j["_err"] -= ep
    return f"{j['name']} sets {ep} EP for Active Defense."

def resolve_reposition(j, ep):
    steps = ep
    j["position"]["x"] += steps if random.random()<0.5 else -steps
    return f"{j['name']} repositions {steps} squares."

def resolve_talk(j, text):
    return f"{j['name']} calls out: \\"{text}\\""

def run_round(chars, rnd, log):
    for ch in chars:
        if ch["_alive"]:
            ch["_err"] = ch["stats"]["ERR"]
            ch["_spoken"] = False
    order = sorted([ch for ch in chars if ch["_alive"]], key=lambda c: -roll_initiative(c))
    log.append(f"\\n## Round {rnd}")
    for ch in order:
        if not ch["_alive"]:
            continue
        others = [o for o in chars if o["id"]!=ch["id"]]
        verb = choose_action(ch, others)
        if verb[0]=="attack" and ch["_err"]>0:
            ep = min(verb[1], ch["_err"]); ch["_err"] -= ep
            tgt = [o for o in others if o["id"]==verb[2]]
            if tgt:
                out = resolve_attack(ch, tgt[0], ep)
            else:
                out = f"{ch['name']} hesitates (no target)."
        elif verb[0]=="defend":
            ep = min(verb[1], ch["_err"]); out = resolve_defend(ch, ep)
        elif verb[0]=="reposition":
            ep = min(verb[1], ch["_err"]); ch["_err"] -= ep; out = resolve_reposition(ch, ep)
        elif verb[0]=="talk":
            out = resolve_talk(ch, verb[1])
        else:
            out = f"{ch['name']} waits."
        log.append(f"- {out}")
    alive_sides = set([ch["side"] for ch in chars if ch["_alive"]])
    end = len(alive_sides) <= 1
    return end

def main():
    chars = [load_char(fp) for fp in INIT.glob("*.json")]
    if not chars:
        print("No characters in initiative/. Copy some in from roster/ first.")
        return
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    md = [f"# Combat Log {stamp}", f"World: {WORLD['name']}"]
    rnd = 1
    while rnd<50:
        if run_round(chars, rnd, md):
            break
        rnd+=1
    sides = [ch["side"] for ch in chars if ch["_alive"]]
    if sides:
        md.append(f"\\n**Outcome:** {sides[0]} stand(s) victorious.")
    else:
        md.append("\\n**Outcome:** Mutual ruin.")
    outpath = LOGS/f"combat_{stamp}.md"
    outpath.write_text("\\n".join(md))
    print(f"Wrote log: {outpath}")
    for ch in chars:
        (INIT/f"{ch['id']}.json").write_text(json.dumps(ch, indent=2))

if __name__ == "__main__":
    main()
