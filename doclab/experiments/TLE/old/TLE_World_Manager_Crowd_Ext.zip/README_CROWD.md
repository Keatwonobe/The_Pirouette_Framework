Crowd Simulator
================

Run a full Parley → Factionalize → Fight loop and produce:
- A **markdown log** (`logs/crowd_*.md`) with narration
- A **numbers trace** table (per-round alive counts) — a helix-like summary
- Per-character **history** entries with an **encounter_key**

Usage:
  cd /mnt/data/tle_world
  python crowd_runner.py            # uses scenes/encounter_example.json
  # or: python crowd_runner.py  (edit the scene file for your own crowd)

Scene format: see scenes/encounter_example.json
 - Reference existing roster IDs, or specify simple templates with count, stats, pools, side, archetype.

History:
 - Each roster character gets a compact history entry that survives beyond the encounter
 - The encounter_key is 12 hex chars derived from (world name, participant IDs, timestamp)

