#!/usr/bin/env python3
import json, random, hashlib, datetime
from pathlib import Path

BASE = Path(__file__).parent
ROSTER = BASE/"roster"
INIT = BASE/"initiative"
SCENES = BASE/"scenes"
LOGS = BASE/"logs"

WORLD = json.loads((BASE/"world.json").read_text())

def load_json(fp): return json.loads(Path(fp).read_text())

def mk_id(prefix, i): return f"{prefix}-{i:03d}"

def mk_from_template(tpl, idx):
    j = {
      "id": mk_id(tpl.get("template","unit"), idx),
      "name": tpl.get("template","Unit").replace("_"," ").title() + f" {idx}",
      "side": tpl.get("side","neutral"),
      "faction": tpl.get("faction","wilds"),
      "persona": {
        "archetype": tpl.get("archetype","pragmatic"),
        "courage": tpl.get("courage",0.5),
        "temper": tpl.get("temper",0.5),
        "tactics": tpl.get("tactics",["focus_fire","use_cover"])
      },
      "stats": {
        "TEP": tpl["stats"]["TEP"], "ERR": tpl["stats"]["ERR"],
        "STR": tpl["stats"]["STR"], "DEX": tpl["stats"]["DEX"],
        "CON": tpl["stats"]["CON"], "INT": tpl["stats"]["INT"], "WIS": tpl["stats"]["WIS"],
        "init_bonus": tpl["stats"]["init_bonus"]
      },
      "pools": {"HP": tpl["pools"]["HP"], "AEP": tpl["pools"]["AEP"], "arcana":[], "skills":[]},
      "form": {"limbs":[{"type":"arm","ep":3},{"type":"arm","ep":3},{"type":"leg","ep":3},{"type":"leg","ep":3}],
               "wings": False},
      "constitution": {"resolve": tpl["stats"]["INT"]+5, "composure": tpl["stats"]["WIS"]+5, "tenets": []},
      "position":{"x":0,"y":0},
      "meta":{"notes":""},
      "history":[]
    }
    return j

def collect_participants(scene):
    chars = []
    for part in scene["participants"]:
        if "id" in part:
            fp = ROSTER/f"{part['id']}.json"
            if fp.exists():
                j = load_json(fp)
                if "history" not in j: j["history"]=[]
                chars.append(j)
        elif "template" in part:
            n = part.get("count",1)
            for i in range(1,n+1):
                j = mk_from_template(part, i)
                chars.append(j)
    return chars

def tn_from_ep(ep):
    return WORLD["rules"]["tn_base"] + (ep//2)

def roll_d20(): return random.randint(1,20)

def init_roll(j):
    return roll_d20() + j["stats"]["init_bonus"] + (j["stats"]["DEX"]//4)

def parley_step(chars):
    stances = {}
    for ch in chars:
        arch = ch["persona"]["archetype"]
        courage = ch["persona"].get("courage",0.5)
        if arch=="cowardly" and random.random() > courage:
            stances[ch["id"]] = "withdraw"
        elif arch=="parleyist":
            stances[ch["id"]] = "ally:parley"
        else:
            stances[ch["id"]] = "fight"
    return stances

def factionalize(chars, stances):
    fighters = [c for c in chars if stances.get(c["id"],"fight")!="withdraw"]
    groups = {}
    for c in fighters:
        key = c.get("side","neutral")
        if stances.get(c["id"]).startswith("ally:"):
            key = stances.get(c["id"])
        groups.setdefault(key, []).append(c)
    if len(groups)==1:
        key = list(groups.keys())[0]
        groups[key] = fighters
    return groups, [c for c in chars if c not in fighters]

def choose_target(me, enemies):
    if not enemies: return None
    enemies.sort(key=lambda e: (e["pools"]["HP"], e["pools"]["AEP"]))
    return enemies[0]

def take_turn(ch, enemies, trace):
    if ch["pools"]["HP"]<=0: return 0, 0
    err = ch["_err"]
    bursty = ch["persona"].get("temper",0.5) > 0.6
    spend = err if bursty else max(1, err//2)
    tn = tn_from_ep(spend)
    atk = roll_d20() + (ch["stats"]["DEX"]//4) + (ch["stats"]["INT"]//4)
    ch["_err"] -= spend
    if atk < tn or not enemies:
        trace.append(f"- {ch['name']} tests the line (miss at EP {spend}, TN {tn}, roll {atk}).")
        return spend, 0
    tgt = choose_target(ch, enemies)
    defend = min(spend, max(0, tgt["_err"]//2))
    tgt["_err"] -= defend
    dmg = max(0, spend - defend)
    soak = min(dmg, tgt["pools"]["AEP"])
    tgt["pools"]["AEP"] -= soak; dmg -= soak
    tgt["pools"]["HP"] -= dmg
    if tgt["pools"]["HP"]<=0: tgt["_alive"]=False
    trace.append(f"- {ch['name']} strikes {tgt['name']} for {dmg} (def {defend}, soak {soak}). {tgt['pools']['HP']} HP.")
    tgt["_taken"] += dmg
    return spend, dmg

def run_crowd(scene_path="encounter_example.json", max_rounds=30):
    scene = json.loads((SCENES/scene_path).read_text())
    chars = collect_participants(scene)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    ids = ",".join(sorted([c["id"] for c in chars]))
    ek = hashlib.sha1((WORLD["name"]+"|"+ids+"|"+ts).encode()).hexdigest()[:12]
    # init state
    for c in chars:
        c["_alive"] = c["pools"]["HP"]>0
        c["_err"] = c["stats"]["ERR"]
        c["_dealt"]=0; c["_taken"]=0
    log = [f"# Crowd Encounter {scene['title']}  ({ek})", f"World: {WORLD['name']}", f"Participants: {len(chars)}"]
    # Parley
    st = parley_step(chars)
    groups, withdrawn = factionalize(chars, st)
    for w in withdrawn:
        log.append(f"- **{w['name']}** withdraws before the clash.")
    # Initiative baseline
    order = sorted([c for c in chars if c["_alive"] and c not in withdrawn], key=lambda c: -init_roll(c))
    helix = []
    rnd = 1
    while rnd<=max_rounds and len([g for g in groups.values() if any(c['_alive'] for c in g)])>1:
        for c in order:
            if c["_alive"]: c["_err"] = c["stats"]["ERR"]
        log.append(f"\\n## Round {rnd}")
        for key, members in groups.items():
            enemies = [e for kk,gg in groups.items() if kk!=key for e in gg if e["_alive"]]
            for ch in [m for m in members if m["_alive"]]:
                spend, dealt = take_turn(ch, enemies, log)
                ch["_dealt"] += dealt
        counts = {k: sum(1 for m in v if m["_alive"]) for k,v in groups.items()}
        helix.append(counts)
        rnd += 1
    survivors = {k:[m for m in v if m["_alive"]] for k,v in groups.items()}
    winners = [k for k,v in survivors.items() if len(v)>0]
    outcome = f"Victors: {', '.join(winners)}" if len(winners)==1 else ("Stalemate" if len(winners)>1 else "Mutual ruin")
    log.append(f"\\n**Outcome:** {outcome}")
    # Numbers table (helix trace)
    keys = list(groups.keys())
    log.append("\\n### Numbers Trace (alive per round)")
    header = "| Round | " + " | ".join(keys) + " |"
    sep = "|---:" + "|".join(["---:"]*len(keys)) + "|"
    log.append(header); log.append(sep)
    for i,c in enumerate(helix, start=1):
        row = "| "+str(i)+" | " + " | ".join(str(c.get(k,0)) for k in keys) + " |"
        log.append(row)
    out = LOGS/f"crowd_{ek}.md"
    out.write_text("\\n".join(log))
    print(f"Wrote crowd log: {out}")
    # Compact history for roster-sourced chars
    for ch in chars:
        src_fp = ROSTER/f"{ch['id']}.json"
        if src_fp.exists():
            src = json.loads(src_fp.read_text())
            hist = src.get("history", [])
            result = "survived" if ch["_alive"] else "fell"
            entry = {"encounter_key": ek, "ts": ts, "role": "crowd", "faction": ch.get("side",""),
                     "rounds": rnd-1, "dealt": int(ch.get("_dealt",0)), "taken": int(ch.get("_taken",0)), "result": result}
            hist.append(entry)
            src["history"] = hist[-50:]
            src_fp.write_text(json.dumps(src, indent=2))

if __name__ == "__main__":
    run_crowd()
